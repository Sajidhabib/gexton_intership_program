<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ADD MULTIPLE ROW DATA</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
	<style type="text/css">
		body{
			text-align: center;
		}
		
		
	</style>
</head>
<body> <br><b></b>
<div id="first">
	<h1>Add Multiple row Data</h1>
</div>
<div>
<form action="multi.php" method="post" class="form-control">
	
	<label>Enter No of Rows</label> 
	<input type="text" name="noofrow"  ><br>
	<br><br>
	<input type="submit" name="nor" value="Submit" id="btn" class="btn btn-primary">
</form>
</div>
</body>
</html>