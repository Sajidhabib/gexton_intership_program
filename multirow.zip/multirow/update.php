<?php
    require('cong.php');
    if (isset($_POST['updt'])) {
        $nor = $_POST['noofrow'];
        for ($i=1; $i <=$nor ; $i++) { 
    
    
            $id = $_POST[$i."id"];
            $name = $_POST[$i."name"];
            $qnty = $_POST[$i."qnty"];
            $price = $_POST[$i."price"];
            $tp = $qnty*$price;
            
            $update="update rows set name='$name',quantity='$qnty',
            price='$price',total_Price='$tp' where id ='$id'";          
              $query  = mysqli_query($conn , $update);
            
        }
        if ($query) {
                ?> <script> alert("Data added Successfully"); </script> <?php
            }
            else {
                echo "no";
            }
    }



?>


<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <h1 class="text-center">Update </h1>

            <div class="row">
            <div class="col-md-offset-2 col-md-8">
            <form action="" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                        <legend>Data</legend>
                    </div>
                   <?php
                    $id=$_GET['id'];
                    $select="select  from rows where id='$id'";
                    //var_dump($select);
                    if($result=$conn->query($select))
                    {
                        if($result->num_rows>0)
                        {  
                            while($row=$result->fetch_array())
                            {
                               // var_dump($row['std_name']);
                    ?>
                    <div class="form-group">
                        <label for="sname" class="col-sm-2 control-label">first Name:</label>
                        <div class="col-sm-10">
                            <input type="text" value=<?php echo $row['first_name'];?> name="fname" id="input" class="form-control"  required="required">
                        </div>
                    </div>
                   <div class="form-group">
                        <label for="age" class="col-sm-2 control-label">Last name:</label>
                        <div class="col-sm-10">
                            <input type="text" value=<?php echo $row['last_name'];?> name="lname" id="input" class="form-control"  required="required">
                                
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="age" class="col-sm-2 control-label">email:</label>
                        <div class="col-sm-10">
                            <input type="text" value=<?php echo $row['email'];?> name="email" id="input" class="form-control"  required="required">
                                
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="age" class="col-sm-2 control-label">course_name:</label>
                        <div class="col-sm-10">
                            <input type="text" value=<?php echo $row['course_name'];?> name="course" id="input" class="form-control"  required="required">
                                
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="age" class="col-sm-2 control-label">Phone:</label>
                        <div class="col-sm-10">
                            <input type="text" value=<?php echo $row['phone'];?> name="phone" id="input" class="form-control"  required="required">
                                
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="age" class="col-sm-2 control-label">gender:</label>
                        <div class="col-sm-10">
                            <input type="text" value=<?php echo $row['gender'];?> name="gender" id="input" class="form-control"  required="required">
                                
                        </div>
                    </div>
                    
                            
                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-2">
                            <input type="submit" class="btn btn-primary" name="btn" value="Update">
                        </div>
                    </div>
                      <?php
                        }}}
                      ?>      

            </form>
            </div>
            </div>

                           </div>            <h3>Sajid Ali Brohi</h3>

            </div>

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>