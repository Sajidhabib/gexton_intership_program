<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ADD MULTIPLE ROW DATA</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
	<style type="text/css">
		body{
			text-align: center;
		}
		
	</style>
</head>
<body>
<div id="first"> <br>
	<h1>Add Multiple row Data</h1>
</div>
<div>
<form action="#" method="post" class="form-group">
	<?php 

	$nor = $_POST['noofrow'];
	for ($i=1; $i<=$nor ; $i++) { 

	?>
	<input type="number" name="<?php echo $i.'id'; ?>" placeholder="Product ID">
	<input type="hidden" name="noofrow" value="<?php echo $nor;  ?>">
	<input type="text" name="<?php echo $i.'name'; ?>" placeholder="Product Name">
	<input type="hidden" name="noofrow" value="<?php echo $nor;  ?>">
	<input type="text" name="<?php echo $i.'qnty'; ?>" placeholder="Product Quantity">
	<input type="hidden" name="noofrow" value="<?php echo $nor;  ?>">
	<input type="text" name="<?php echo $i.'price'; ?>" placeholder="Product Price">
	<input type="hidden" name="noofrow" value="<?php echo $nor;  ?>">
	<br><br>

	<?php

	}
	?>
	<input type="submit" name="submit" value=" Save " id="btn" class="btn btn-info">
		<a name="updt" href="update.php" class="btn btn-primary">Update</a>
</form>
</div>
</body>
</html>


<?php
require('cong.php');

if (isset($_POST['submit'])) {
	$nor = $_POST['noofrow'];
	for ($i=1; $i <=$nor ; $i++) { 


		$id = $_POST[$i."id"];
		$name = $_POST[$i."name"];
		$qnty = $_POST[$i."qnty"];
		$price = $_POST[$i."price"];
		$tp = $qnty*$price;
		
		$insert = "INSERT INTO `rows` (id , name , quantity , price , total_Price)VALUES('$id' , '$name' , '$qnty', '$price' , '$tp')";
		$query  = mysqli_query($conn , $insert);
		
	}
	if ($query) {
			?> <script> alert("Data added Successfully"); </script> <?php
		}
		else {
			echo "no";
		}
}



?>