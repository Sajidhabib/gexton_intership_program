<?php
$conn = mysqli_connect("localhost" , "root" , "" , "multiple_rows");
if(!$conn){
    die;
}
else{
    echo "connected";
}

?>