<?php
    require('config.php');
    if(isset($_POST['btn']))
    {
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $course=$_POST['course'];
    $phone=$_POST['phone'];
    $gender=$_POST['radio'];
   


    $insert ="INSERT INTO `task_two`(`first_name`, `last_name`, `email`, `course_name`, `phone`, `gender`) 
    VALUES ('$fname','$lname','$email','$course','$phone','$gender')";
    if($conn->query($insert)==true)
    {
        
       
        header('location:view.php');
    }
    else
    {
        echo "There is some error  inserting data";
    }

    }

   


?>


<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <h1 class="text-center">Insert Student Record</h1>

            <div class="row">
            <div class="col-md-offset-2 col-md-8">
            <form action="" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                        <legend>Student Data Form</legend>
                    </div>
                    
                    <div class="form-group">
                        <label for="fname" class="col-sm-2 control-label">First Name:</label>
                        <div class="col-sm-10">
                            <input type="text" name="fname" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="lname" class="col-sm-2 control-label">Last Name:</label>
                        <div class="col-sm-10">
                            <input type="text" name="lname" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-sm-2 control-label">Email :</label>
                        <div class="col-sm-10">
                            <input type="text" name="email" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="course" class="col-sm-2 control-label">Course Name:</label>
                        <div class="col-sm-10">
                            <input type="text" name="course" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="phone" class="col-sm-2 control-label">Phone:</label>
                        <div class="col-sm-10">
                            <input type="text" name="phone" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                    <label>
                             <input type="radio" name="radio" value="Male">Male
                     </label>
                     <label>
                            <input type="radio" name="radio" value="Female">Female
                    </label>
                        
                    </div>
                    
            
                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-2">
                            <input type="submit" class="btn btn-primary" name="btn" value="Add">
                        </div>
                    </div>


            </form>
            <h3>Sajid Ali Brohi</h3>
            </div>
            </div>

           

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>