<?php require('config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>
<body>
<div class="row">
     <div class="col-md-offset-2 col-md-8">
<?php
 
    
$sql = "select std_id , first_name , last_name , email , course_name , phone , gender from task_two";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)>0) {
             echo '<table class="table table-responsive">
             <tr>
             <th> ID</th>
             <th> First Name</th>
             <th> Last Name</th>
             <th>Email</th>
             <th>Course</th>
             <th>phone</th>
             <th>gender</th>
             </tr>
             ';
  while($row = mysqli_fetch_array($result) ) {
                    $id=$row['std_id'];
                 echo '<tr>';
                 echo '<td>'.$row['std_id'].'</td>';
                 echo '<td>'.$row['first_name'].'</td>';
                 echo '<td>'.$row['last_name'].'</td>'; 
                 echo '<td>'.$row['email'].'</td>'; 
                 echo '<td>'.$row['course_name'].'</td>'; 
                 echo '<td>'.$row['phone'].'</td>';   
                 echo '<td>'.$row['gender'].'</td>'; 
                 echo "<td> <a href='update.php?std_id=$id' class='btn btn-primary'>Update</a> 
                 <a href='view.php?std_id=$id' onclick='delete()' class='btn btn-danger'>Delete</a>
                 </td>";
                 echo '</tr>';
             }
             echo '</table>';
         }
  
 else {
  echo "0 results";
}
if(isset($_GET['std_id']))
{
    $id=$_GET['std_id'];
    //delete query
    $delete="delete from task_two where std_id=$id";
    if($conn->query($delete)==true)
    {
       ?>  <script> alert("Data Deleted Successfully") </script><?php 
    }
    else
    {
        echo "There is some error while deleting data";
    }
}
mysqli_close($conn);
?> 

   
     </div>
 </div>
 <h3>Sajid Ali Brohi</h3>


</body>
</html>
