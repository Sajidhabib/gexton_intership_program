<?php

    $conn= mysqli_connect('localhost','root','','gexton_edu');

    if($conn->connect_error)
    {
        die("ERROR: Could not connect. " . $conn->connect_error);
    }
    // Print host information
//    echo "Connect Successfully. Host info: " . $conn->host_info;

   ?>    <script> alert("Data Inserted") </script>
