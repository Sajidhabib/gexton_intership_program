-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2022 at 02:17 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gexton_edu`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `std_id` int(10) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`std_id`, `first_name`, `last_name`, `email`, `course`) VALUES
(1, 'Sajid', 'Habib', 'brohisajid786@gmail.com', 'Web develpoment'),
(2, 'Rahid', 'Nazeer', 'brohi6755@gmail.com', 'Python'),
(3, 'Ishtiaque', 'Ali', 'ishtiaq@gmail.com', 'Graphics '),
(4, 'Zahid', 'arshafd', 'brohi123@gmail.com', 'Java Core'),
(5, 'Rizwan', 'Ali', 'rizwan123@gmail.com', 'Webdevelopment');

-- --------------------------------------------------------

--
-- Table structure for table `task_two`
--

CREATE TABLE `task_two` (
  `std_id` int(11) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task_two`
--

INSERT INTO `task_two` (`std_id`, `first_name`, `last_name`, `email`, `course_name`, `phone`, `gender`) VALUES
(4, 'karam', 'ullah', 'karam@gmail.com', 'seo', '03336668313', 'Male'),
(5, 'Sajjad hussain', 'brohi', 'sajidhabibbrohi786@gmail.om', 'Graphics ', '123456', 'Male'),
(6, 'Maria', 'Afzal', 'mariaafzal@gmal.com', 'SEO', '033312123000', 'Female'),
(8, 'Shakeela', 'Habib', 'habib7862@gmail.com', 'Web develpoment', '0333444556', 'Female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`std_id`);

--
-- Indexes for table `task_two`
--
ALTER TABLE `task_two`
  ADD PRIMARY KEY (`std_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `std_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `task_two`
--
ALTER TABLE `task_two`
  MODIFY `std_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
