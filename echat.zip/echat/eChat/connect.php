<?php
$con = mysql_connect("localhost","root","");
$db = mysql_select_db("echatDB") or die("Cant connect to DB");
?>