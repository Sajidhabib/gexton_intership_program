<?php
$conn = mysqli_connect("localhost","root","","echatdb") or die("Cant connect to DB");
?>