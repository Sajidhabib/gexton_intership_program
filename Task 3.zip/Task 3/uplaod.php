<?php require('config.php');
 if(isset($_POST['btn']))
 {
 $fname=$_POST['fname'];
 $fees=$_POST['fees'];
 $course=$_POST['course'];
 $img=$_POST['image'];
 



 $insert ="INSERT INTO `users`(`fullname`, `fees`, `course_name`, `image`) 
 VALUES ('$fname','$fees','$course','$img')";
 if($conn->query($insert)==true)
 {
     
    
     header('location:view.php');
    // echo "Data inserted into database";
 }
 else
 {
     echo "There is some error  inserting data";
 }

 }


?>;
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uplaod</title>
    <script src="js/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container"> 
   

    <div class="row" class="outline-5">
    <form action="" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                        <legend>Student Data Form</legend>
                    </div>
                    
                    <div class="form-group">
                        <label for="fname" class="col-sm-2 control-label">Full Name:</label>
                        <div class="col-sm-10">
                            <input type="text" name="fname" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="fees" class="col-sm-2 control-label">Fees:</label>
                        <div class="col-sm-10">
                            <input type="text" name="fees" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="course" class="col-sm-2 control-label">Course Name:</label>
                        <div class="col-sm-10">
                            <input type="text" name="course" id="input" class="form-control" value="" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="phone" class="col-sm-2 control-label">Image:</label>
                        <div class="col-sm-10">
                            <input type="file" name="image" onchange="getImage(event);" id="uplaod_file" class="form-control" value="">
                        </div>
                    </div>   <br> 
                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-2">
                            <input type="submit" class="btn btn-primary" name="btn" value="Uplaod">
                        </div>
                    </div>


            </form>
    </div>
 </div><br>
 <div class="btn_dl btn-danger"onclick="deleteImg()" style="width:7%;padding:10px;margin-left:300px;text-align:center;">
 <a style="color:white;text-decoration:none" href="">Delete</a></div>

 <div id="preview" style="margin-left:50px; width:350px;height:">
</div>
 <br>
<script>
    function getImage(event){
     var image = URL.createObjectURL(event.target.files[0]);
     var imagediv = document.getElementById('preview');
     var newimage = document.createElement('img');
     newimage.src=image;
     newimage.width="350";
     imagediv.appendChild(newimage);
    }
    function deleteImg(){
        imagediv.innerHTML='';
    }
</script>
</body>
</html>