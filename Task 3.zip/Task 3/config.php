<?php
$server = 'localhost';
$username = 'root';
$passowrd = '';
$dbname = 'gexton_education';

$conn = mysqli_connect($server,$username,$passowrd,$dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
//   echo "Connected successfully";



?>