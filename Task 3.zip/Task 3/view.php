<?php require('config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
<style>
    .main-div{
        padding:50px; margin:auto;
        margin-top:30px;
        /* text-align:center; */
    }
    table{
        text-align: center;
        width:100%;
    }
    th{
        background:grey;
        color:white;
    }
    td{
        background:lightgrey;
    }
    .new-btn{
        color:white;
        text-decoration:none;
    }
</style>
</head>
<body>
<div class="row">
    
     <div class="col-md-offset-2 col-md-8 main-div ">
        <h6 class="text-success">View Data</h6>
        <button type="button" class="btn btn-primary"><a class="new-btn" href="uplaod.php">Add New</a></button>

<?php
 ob_start();
    
$sql = "select std_id , fullname , fees ,  course_name , image  from users";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)>0) {
             echo '<table class="table table-responsive"style="margin:auto">
             <tr>
             <th> ID</th>
             <th> Full Name</th>
             <th> Fees</th>
             <th>Course</th>
             <th>Images</th>
             <th>Button</th>
             </tr>
             ';
  while($row = mysqli_fetch_array($result) ) {
                    $id=$row['std_id'];
?>
            <tr>
                <td> <?php echo $row['std_id']?></td>
                <td> <?php echo $row['fullname'] ?></td>
                <td> <?php echo $row['fees']?></td>
                <td> <?php echo $row['course_name']?></td>
                <td> <img src="./ing/<?php  echo $row['image'];?>" style="width:100px;" > </td>  
                <?php echo '<td> <a href="view.php?std_id='.$id.'"  class="btn btn-danger">Delete</a>
                 </td>';
                 echo '</tr>';
             }
             echo '</table>';
         }
  
 else {
  echo "0 results: ";
}

if(isset($_GET['std_id']))
{
    
    $id=$_GET['std_id'];
    //delete query
    $delete="delete from users where std_id=$id";
    if($conn->query($delete)===true)
    {
      echo"Data Deleted Successfully." ;
      header("Location: /task%203/view.php");
    }
    else
    {
        echo "There is some error while deleting data";
    }
}
mysqli_close($conn);
?> 

   
     </div>
 </div>


</body>
</html>
