<?php 

$pass = "123456";
echo md5($pass);

?> 