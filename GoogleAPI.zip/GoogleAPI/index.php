<?php
require_once 'config.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="css/style.css"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css" integrity="sha384-eoTu3+HydHRBIjnCVwsFyCpUDZHZSFKEJD0mc3ZqSBSb6YhZzRHeiomAUWCstIWo" crossorigin="anonymous">
</head>
<body>

<div class="container"><br><br>
 <div class="form_con text-center " style="border:1px solid lightgrey;"><br><br>
    <h2>Sign up with</h2> <br>
    <div class="mb-3 row">
    <label for="staticEmail" class="col-sm-3 col-form-label">Email</label>
    <div class="col-sm-6">
      <input type="text"  class="form-control" id="staticEmail" value="">
    </div>
 </div>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-3 col-form-label">Password</label>
    <div class="col-sm-6">
      <input type="password" class="form-control" id="inputPassword">
    </div>
  </div>


OR <br><br>
</body>
</html>         
 <?php
  echo "<a class='btn btn-danger' href='".$client->createAuthUrl()."'>Google Login <i class='bi bi-google'></i> </a>";

?>
<br><br><br>
</div>
</div>