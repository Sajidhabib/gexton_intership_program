<?php
require_once 'config.php';


if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $client->setAccessToken($token['access_token']);
  
    // get profile info
    $google_oauth = new Google_Service_Oauth2($client);
    $google_account_info = $google_oauth->userinfo->get();
    $fname = $google_account_info->givenName;
    $lname = $google_account_info->familyName;
    $email =  $google_account_info->email;
    $gender = $google_account_info->gender;
    $name =  $google_account_info->name;
    $pic =  $google_account_info->picture;
    $verfied = $google_account_info->verifiedEmail;
    $token = $google_account_info->id;
    // echo"<h1> ",$name ."</h1>";

    require_once 'database.php';

$insert = "INSERT INTO `users`(`fist_name`, `last_name`, `email`, `full_name`, `gender`, `picture`, `verfied_email`, `token`)
VALUES ('$fname','$lname','$email','$name','$gender','$pic','$verfied','$token')";
if(mysqli_query($conn,$insert)){
   echo "Data is inserted into the databse";
}
else{
    echo "<p style='color:red'> Duplicate Entry Not Allowed. Your email is already registerd </p>"; 
}
  }
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wekcome to google</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <style>
        .logo{
            border:1px solid black;
            width:120px;
            border-radius:100%;
        }
        .logo img{
            border-radius:100%;
        }
        table{
            border:1px solid grey;
            width:100%;
            text-align:center;
        }
        td{
            padding:10px;
        }
        th{
            padding:10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <br><br> <h3>Login User</h3>
                    <table >
                        <tr>
                            <th>Logo</th>
                            <th>Full Name</th>
                            <th>Email Address</th>
                            <th>Button</th>
                        </tr>
                        <tr>
                            <td><div class="logo"> <img src="<?php echo" $pic" ;?>" alt="profile image" width="100%"></div></td>
                            <td><div class="name"> <h3> <?php echo " $name";?></h3></div></td>
                            <td><div class="email"><b><?php echo "$email";?></b> </div></td>
                            <td> <button class="btn btn-primary"><a class="text-white " href="data.php"> View All Data</a></button></td>
                        </tr>
                    </table>
                   
                
            </div>
        </div>
    </div>
  
</body>
</html>