<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "googleapi";

$conn = mysqli_connect($server,$username,$password,$dbname);
if(!$conn){
    echo "error while connecting";
}
else{
    // echo "connected";
   
}

?>