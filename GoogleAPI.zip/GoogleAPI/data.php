<?php 
            require_once 'database.php';
             echo "<h1 align='center'> Signed up users </h1> <br>";
                $sql ="SELECT * FROM users";   
                $result = $conn->query($sql);
                if(mysqli_num_rows($result) > 0 ){
                    echo "<table class='table table-primary' style='width:100%; text-align:center; 
                     border: 1px solid black;'>
                    <tr style='background:grey; padding:10px'> 
                    <th> ID </th>
                    <th> First Name </th>
                    <th> Last Name </th>
                    <th> Email </th>
                    <th> Full Name </th>
                    <th> Gender </th>
                    <th> Image </th>
                    <th> Verfied Email </th>
                    <th> Token </th>
                    </tr>";

                }  
            while($row = mysqli_fetch_array($result)){
                $id=$row['id'];
                echo "<tr style='background: lightgrey;'>";
                echo '<td>'.$row['id'].'</td>';
                echo '<td>'.$row['fist_name'].'</td>';
                echo '<td>'.$row['last_name'].'</td>'; 
                echo '<td>'.$row['email'].'</td>'; 
                echo '<td>'.$row['full_name'].'</td>'; 
                echo '<td>'.$row['gender'].'</td>';   
                echo '<td>'?><img src="<?php echo $row['picture'] ?>" alt="profile"><?php '</td>'; 
                echo '<td>'.$row['verfied_email'].'</td>'; 
                echo '<td>'.$row['token'].'</td>'; 
                echo "</tr>";
               

            }
            echo "</table>";
            ?> 