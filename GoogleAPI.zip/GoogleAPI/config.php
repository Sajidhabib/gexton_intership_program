<?php
require_once 'vendor/autoload.php';

$clientID = '131953306120-m8b77kd4j7689neibtnsp8gegdg1qd3p.apps.googleusercontent.com';
$clientSecret = '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';
$redirectUri = 'http://localhost/GoogleAPI/welcome.php';


$client = new Google_Client();
$client->setClientId($clientID);
$client->setClientSecret($clientSecret);
$client->setRedirectUri($redirectUri);
$client->addScope("email");
$client->addScope("profile");



?>