<?php 
require('./config.php');
session_start();
$id = $_SESSION['id'];
$fname = $_SESSION['fname'];
$lname = $_SESSION['lname'];
$email = $_SESSION['email'];
$phone = $_SESSION['phone'];
$course =$_SESSION['course'];
$gender = $_SESSION['gender'];
$address = $_SESSION['adress'];
$postal = $_SESSION['postal'];


require('./pages/updatedatapage.php');


if (isset($_POST['submit'])){

 

  $fname = $_POST["fname"];
  $lname= $_POST["lname"];
  $email = $_POST["email"];
  $phone = $_POST["phone"];
  $course = $_POST["course"];
  $gender= $_POST["gender"];
  $address=$_POST["adress"];
  $postal=$_POST["postal"];

  $db_update_data = new curdSystem();
  $db_update_data->updateStd($id,$fname,$lname
  ,$email,$phone,$course,$gender,$address,$postal);
  
  header("Location: /gexton_task5/index.php");
  
}

exit;






?>