<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Add Data</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-12 col-lg-8 col-md-10">
      <div class="card mx-5 my-5 p-4 shadow p-3 mb-5 bg-white rounded border-light ">
      <div class="row  justify-content-center ">
        <div class="col-auto" >
          <label for="fname" class="form-label"><h5 class="card-title">Add new student data</h5></label>

        </div>

      </div>
      <div class="row justify-content-center">
       <form method="post" id = "form1" runat = "server" enctype="multipart/form-data">
       <div class="mb-3">
           <label for="fname" class="form-label">First Name</label>
           <input type="text" class="form-control" name="fname" id="fnameID" autofocus="autofocus" required >
       </div>
       <div class="mb-3">
          <label for="lname" class="form-label">Last Name</label>
          <input type="text" class="form-control" name="lname" id="lnameID"  required>
          </div>
       <div class="mb-3">
          <label for="em" class="form-label">Email</label>
          <input type="email" class="form-control" name="email" id="emailID" aria-describedby="emailError" required>
          <div id="emailHelp" class="form-text">please enter your valid email</div>
        </div>
       <div class="mb-3">
          <label for="phone_number" class="form-label">Phone Number</label>
          <input type="text" class="form-control" id="phoneID" name="phone" required>
          </div>
      

       <div class="mb-3">
          <label for="course" class="form-label">Course Selection</label>
          <select name="course" class="form-control" name="course">
          <option value="1">Web Programming</option>
          <option value="2" >Artificial intelligence</option>
          <option value="3">Graphic Design</option>
          </select>
       </div>

       <div class="col-xsm mb-3">
         <label for="gn" class="form-label">gender</label>
         <select name="gender" class="form-control" >
         <option value="1">Male</option>
         <option value="2" >Female</option>
         <option value="3">other</option>
         </select>
        </div>
      </div>
      <div class="mb-3">
          <label for="em" class="form-label">Address</label>
          <input type="text" class="form-control" name="adress" id="emailID" aria-describedby="emailError" required>
          <div id="emailHelp" class="form-text">please enter your valid email</div>
        </div>
        <div class="mb-3">
          <label for="em" class="form-label">Postal code</label>
          <input type="text" class="form-control" name="postal" id="emailID" aria-describedby="emailError" required>
          <div id="emailHelp" class="form-text">please enter your valid email</div>
        </div>
      <div class="row justify-content-center">
      <div class="col-3">
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
      </div>
      <div class="col-3">
        <a href="index.php" class="btn btn-outline-primary">Cancel</a>
      </div>
      </div>

     

      </form>

      </div>
    </div>

  </div>

</div>


</body>
</html>
