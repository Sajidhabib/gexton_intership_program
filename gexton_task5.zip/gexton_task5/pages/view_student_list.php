


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php $root= realpath($_SERVER["DOCUMENT_ROOT"]); echo $root;?>/gexton_task5/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>View Page</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<div class="container">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
            <form method="post">
            <div class="row g-5 my-5">
                    
                    <div class="col-6  mx-4"><h2>Student <b>Details</b></h2></div>
                    <div class="col-auto  mx-3 ">
                       <a class="btn btn-primary add-new" href="?run=add_new" style="text-decoration: none;color:white;">Add New</a>
                    </div>
                    <div class="col-auto">
                        
                       <button class="btn btn-success" id="mutlicheck" name="submit"   style="text-decoration: none;color:white;">export multi rows</button>
                        
                    </div>
                    <div class="col-auto">
                       <a class="btn btn-danger" id="export_all"  style="text-decoration: none;color:white;">export all</a>
                    </div>
                </div>
            </div>
           
            <div id="table_data" >
            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th></th>  
                       <th>ID</th>  
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>phone</th>
                        <th>Course</th>
                        <th>gender</th>
                        <th>Address</th>
                        <th>Postal Code</th>
                        <th>Edit & Delete</th>
                    </tr>
                </thead>
                <tbody>

               
                    
                        <?php
                        $root = realpath($_SERVER["DOCUMENT_ROOT"]);
                        
                        require("$root/gexton_task5/config.php"); 

                        $db = new curdSystem();
                        $viewList = $db->viewStdData();
                        
                        if ($viewList!=null) {
                          
                   
                        while($row = $viewList->fetch_assoc()) {

                            $id = $row["id"];
                            $fname = $row["first_name"];
                            $lname = $row["last_name"];
                            $email = $row["email"];
                            $phone = $row["phone"];
                            $course = $row["course"];
                            $gender = $row["gender"];
                            $address =$row['adress'];
                            $postal = $row['postal'];

                            
                      
                            echo '<td><input type="checkbox" name="checkes[]" value="'.$id.'"></td>';
                            echo '<td>'.$id.'</td>';
                            echo "<td><input type="."hidden"." name="."id"." value="."$id"."><input type="."hidden"." name="."fname"." value="."$fname".">".$row["first_name"]."</td>"
                            ."<td><input type="."hidden"." name="."lname"." value="."$lname".">".$row["last_name"]."</td>"
                            ."<td><input type="."hidden"." name="."email"." value="."$email".">".$row["email"]."</td>"
                            ."<td><input type="."hidden"." name="."phone"." value="."$phone"."><input type="."hidden"." name="."course"." value="."$course"."><input type="."hidden"." name="."gender"." value="."$gender".">".$row["phone"]."</td>";

                            switch($row["course"]){
                                
                                case 1:
                                    echo "<td>Web Programming</td>";
                                    break;
                                case 2:
                                    echo "<td>Artificial intelligence</td>";
                                    break;
                                case 3:
                                    echo "<td>Graphic Design</td>";
                                    break;

                            }

                            switch($row["gender"]){
                                
                                case 1:
                                    echo "<td>Male</td>";
                                    break;
                                case 2:
                                    echo "<td>Female</td>";
                                    break;
                                case 3:
                                    echo "<td>Other</td>";
                                    break;

                            }
                            echo "<td><input type="."hidden"." name="."fname"." value="."$address".">".$row["adress"]."</td>";
                            echo "<td><input type="."hidden"." name="."fname"." value="."$postal".">".$row["postal"]."</td>";

                            
                            
                            echo "<td>
                            <button class="."btn btn-primary"."  name="."edit"."><i class="."material-icons".">&#xE254;</i></button>
                            <button class="."btn btn-success"."  name="."delete"."><i class="."material-icons".">&#xE872;</i></button>
                        </td></tr>";

                           
   
                       }
                    
                    }

                
                        ?>

                    
                      
                        
                    
                     
                </tbody>
            </table>
            </div>    

            <script type="text/javascript">
   
          $( document ).ready(function() {
              
         $('#export_all').click(function(){

            var table = $('#table_data').html();
          window.location = ("export.php?table_data="+encodeURIComponent(table));
          
         });

       

           });
             
          

            </script>

            </form>
     <?php 
     
     if (isset($_POST['delete'])){

        $id = $_POST["id"];

        $db = new curdSystem();
        $db->deleteStudent($id); 
        header("Location: /gexton_task5/index.php");
    }

    if ((isset($_POST['edit']))){
        
       
        session_start(); 
        $_SESSION['id'] = $_POST["id"];
        $_SESSION['fname'] = $_POST["fname"];
        $_SESSION['lname'] = $_POST["lname"];
        $_SESSION['email'] = $_POST["email"];
        $_SESSION['phone'] = $_POST["phone"];
        $_SESSION['course'] = $_POST["course"];
        $_SESSION['gender'] = $_POST["gender"];

        header("Location: /gexton_task5/edit_page.php");

        exit;

    }

     ?>


        </div>
    </div>
</div>  
  

</body>
</html>