<?php

class curdSystem{

public $conn;
function __construct(){
    $this->getConnection();
}

function getConnection(){
$serName = "localhost";
$uName = "root";
$pName = "";
$dbName = "gexton_task5_db";

// Create connection
$this->conn = new mysqli($serName, $uName, $pName, $dbName);
// Check connection
if ($this->conn->connect_error) {
  die("Connection failed: " . $this->conn->connect_error);
}

    }

 function insertStdData($fName,$lName,$email,$phone,$course,$gender,$address,$postal){
  
    $sql = "INSERT INTO task5 (first_name,last_name,email,phone,course,gender,adress,postal)
VALUES ('$fName', '$lName', '$email','$phone','$course','$gender','$address','$postal')";

if ($this->conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $this->conn->error;
}
$this->conn->close();
 }


 public function viewStdData(){
  
    $sql = "select * from task5";

    $result = $this->conn->query($sql);

    return $result;
$this->conn->close();
 }


 public function deleteStudent($id){
    $sql = "DELETE FROM task5 WHERE id=$id";
    echo "id :".$id;

if ($this->conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $this->conn->error;
}
$this->conn->close();

 }




  function updateStd($id,$fName,$lName,$email,$phone,$course,$gender){

    $sql = "UPDATE task5 SET first_name='$fName',last_name='$lName',email='$email',phone='$phone',course=$course,gender=$gender,addres=$address,postal=$postal WHERE id=$id";

    if ($this->conn->query($sql) === TRUE) {
      echo "Record updated successfully";
    } else {
      echo "Error updating record: " . $this->conn->error;
    }
    
    $this->conn->close();

 }

 
 function selectRowsFormIds($id){

  $sql = "select * from task5 where id =".$id;

  $result = $this->conn->query($sql);

  return $result;
$this->conn->close();






 }

 

}


?>