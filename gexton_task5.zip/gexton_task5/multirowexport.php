<?php
 session_start(); 

   header('Content-Type:application/vnd.ms-excel');
   header('Content-Disposition:attachment;filename=myfile'.rand().'.xls');
    echo $_SESSION["table_data"];

 session_destroy();
    

   
?>
