<?php 
ob_start();
require('./pages/add_new_student.php');
require('./config.php');

  
if (isset($_POST['submit'])){

    $fName = $_POST["fname"];
    $lName = $_POST["lname"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $course = $_POST["course"];
    $gender = $_POST["gender"];
    $address=$_POST["adress"];
    $postal=$_POST["postal"];
    
    

    $db_insert_data = new curdSystem();
    $db_insert_data->insertStdData($fName,$lName
    ,$email,$phone,$course,$gender,$address,$postal);


    
    header("Location: /gexton_task5/index.php");
        ob_end_flush();  

    
    

    }



?>