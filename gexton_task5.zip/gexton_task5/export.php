<?php

   header('Content-Type:application/vnd.ms-excel');
   header('Content-Disposition:attachment;filename=myfile'.rand().'.xls');
  
       echo $_GET["table_data"];
     
   
?>