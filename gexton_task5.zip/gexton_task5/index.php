<?php
ob_start();
require('./pages/view_student_list.php');




if (isset($_POST["submit"])){
    $check = array();

    if (isset($_POST["checkes"])){
    $check = $_POST["checkes"];

  

   
if (!empty($check)){

    $multiRowTable = "<div class="."container".">
    <div class="."table-responsive".">
        <div class="."table-wrapper".">
            <div class="."table-title".">  <table class="."table table-bordered".">
                <thead>
                    <tr>
                    
                       <th>ID</th>  
                        <th >First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>phone</th>
                        <th>Course</th>
                        <th>gender</th>
                        
                    </tr>
                </thead>
                ";
    


    foreach ($check as $id){
       
        
        $viewList = $db->selectRowsFormIds($id);


        if ($viewList!=null) {
       

          $list =$viewList->fetch_assoc();

          $idfordb = $list["id"];
          $fname = $list["first_name"];
          $lname = $list["last_name"];
          $email = $list["email"];
          $phone = $list["phone"];
          $course = $list["course"];
          $gender = $list["gender"];


          $multiRowTable.= " <tbody><tr><td>".$idfordb."</td>";
          $multiRowTable.= "<td>".$fname."</td>"
          ."<td>".$lname."</td>"
          ."<td>".$email."</td>"
          ."<td>".$phone."</td>";

          switch($course){
              
              case 1:
                $multiRowTable.= "<td>Web Programming</td>";
                  break;
              case 2:
                $multiRowTable.= "<td>Artificial intelligence</td>";
                  break;
              case 3:
                $multiRowTable.= "<td>Graphic Design</td>";
                  break;

          }

          switch($gender){
              
              case 1:
                $multiRowTable.= "<td>Male</td>";
                  break;
              case 2:
                $multiRowTable.= "<td>Female</td>";
                  break;
              case 3:
                $multiRowTable.= "<td>Other</td>";
                  break;

          }

          
          $multiRowTable.="  </tr></tbody></table></div></div>";

   
         
        }}


        
      

        session_start(); 
        $_SESSION["table_data"]=$multiRowTable;
        header("Location: /gexton_task5/multirowexport.php");
       
       
        
    
 

}}

}


if (isset($_GET['run']) && $_GET['run'] == 'add_new'){

    session_start(); 
    $_SESSION['foo'] = "zain";
    header("Location: /gexton_task5/add_new.php");
    
    exit;
}

?>
