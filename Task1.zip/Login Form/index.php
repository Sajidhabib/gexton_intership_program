<?php include('config.php') ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="main">
        <div class="box">
            <div class="contents">
                <div class="heading">
                    <h4>INSERT FORM DATA INTO DATABASE USING PHP</h4>
                    <hr>
                </div>
                <br>
                <div class="form">
                    <form action="" method="POST">
                        <label for="fname">First Name:</label> <br>
                        <input  type="text" required  name="fname" placeholder="Enter Your Name" id="name"> <br>
                        <label for="lname">Last Name:</label> <br>
                        <input  type="text" required  name="lname" placeholder="Enter Your Last Name"><br>
                        <label for="email">Email: </label> <br>
                        <input  type="text" required name="email"  placeholder="Email Adress"><br>
                        <label for="course">Course: </label> <br>
                        <input  type="text" required  name="course" placeholder="Course Name"><br> <br>
                        <div class="button">
                            <input type="submit" value="Signup" name="submit">
                        </div>
  
                    </form>
                    <h4>Sajid Ali Brohi</h4>
                </div>
            </div>
        </div>
    </div>
</body>

</html>