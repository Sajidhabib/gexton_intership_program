<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gexton_edu";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['submit'])){

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$course = $_POST['course'];

$sql = "INSERT INTO student (First_name, Last_name, email , course)
 VALUES ('$fname', '$lname','$email','$course')";

if (mysqli_query($conn, $sql)) {
//   echo "New record created successfully";
  ?><script> alert("Data Added Successfully. ") </script>
  <?php 
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}


?>
