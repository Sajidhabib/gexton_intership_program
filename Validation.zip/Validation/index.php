<?php include('config.php') ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<style>
    .error{
    color:red;
}
</style>
<body>
    <div class="main">
        <div class="box">
            <div class="contents">
                <div class="heading">
                    <h4>Form Validation</h4>
                    <hr>
                </div>
                <br>
                <div class="form">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
                        <label for="fname">First Name:</label> <br>
                        <input  type="text"   name="fname" placeholder="Enter Your Name" id="name">
                        <span class="error">* <br> <?php echo $fnameErr;?></span>
                        <br><br>
                        <label for="lname">Last Name:</label> <br>
                        <input  type="text"   name="lname" placeholder="Enter Your Last Name">
                        <span class="error">* <br> <?php echo $lnameErr;?></span>
                        <br><br>
                        <label for="email">Email: </label> <br>
                        <input  type="text"  name="email"  placeholder="Email Adress">
                        <span class="error">* <br> <?php echo $emailErr;?></span>
                        <br><br>
                        <label for="password">Password: </label> <br>
                        <input  type="password"  name="Password"  placeholder="Password ">
                        <span class="error">* <br> <?php echo $passwordErr;?></span>
                        <br><br>
                        <label for="course">username: </label> <br>
                        <input  type="text"   name="username" placeholder="username">
                        <span class="error">* <br> <?php echo $usernameErr;?></span>
                        <br><br>
                        <label for="fees">Course: </label> <br>
                        <input  type="" text name="course"  placeholder="course">
                        <span class="error">* <br> <?php echo $courseErr;?></span>
                        <br><br>
                        <label for="dddress">Address: </label> <br>
                        <input  type="text"  name="dddress"  placeholder="Address ">
                        <span class="error">* <br> <?php echo $addressErr;?></span>
                        <br><br>
                        <div class="button">
                            <input type="submit" value="Register" name="submit">
                    </div>
  
                    </form>
                    <h4>Sajid Ali Brohi</h4>
                </div>
            </div>
        </div>
    </div>
</body>

</html>