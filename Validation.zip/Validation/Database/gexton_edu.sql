-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2022 at 11:41 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gexton_edu`
--

-- --------------------------------------------------------

--
-- Table structure for table `validate`
--

CREATE TABLE `validate` (
  `id` int(10) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `passw` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `validate`
--

INSERT INTO `validate` (`id`, `first_name`, `last_name`, `email`, `passw`, `username`, `course`, `address`) VALUES
(1, 'sajid', 'habib', 'sajidhabibbrohi786@gmail.om', '12345', 'sajidhabib', 'Graphics', 'kotri'),
(2, 'inam', 'ullah', 'inam@gmail.com', '123456', 'inam676', 'Website development', 'kotri'),
(3, 'Sajid', 'ali', 'brohisajid786@gmail.com', '4c4f9b00ac51ac0c7d5ce07077fbc426', 'sajidhabib', 'Website development', 'jasmhoro'),
(4, 'Habib', 'Ullah', 'Brohihabib@gmail.com', 'c93c75b7929a3897589cf52085fb0279', 'habibbrohi', 'web', 'kotri'),
(5, 'Nasir', 'Habib', 'brohi7954@gmail.com', '7b5f85ecce8e0a8b9a5ec8ace9cd302a', 'Sajid', 'Web develpoment', 'jasmhoro'),
(6, 'Slman', 'Iqbal', 'salman@gmail.com', 'c95027b2bc8c423221da21ce3176ecd4', 'salmansahab', 'Graphics', 'Hyderabad'),
(7, 'Ishtiaque', 'Hussain', 'ishktiaq@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'username', 'Develpment', 'Hyderaabd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `validate`
--
ALTER TABLE `validate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `validate`
--
ALTER TABLE `validate`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
