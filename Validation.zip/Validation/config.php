<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gexton_edu";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$fnameErr = $lnameErr  = $emailErr = $passwordErr = $usernameErr = $courseErr = $addressErr = "";
$fname = $lname = $email = $pass = $user = $course =$address = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["fname"])) {
    $fnameErr = "First Name is required";
  } else {
    if (!preg_match("/^[a-zA-Z-' ]*$/",$fname = test_input($_POST['fname']))) {
      $fnameErr = "Only letters and white space allowed";
    }
  }
  if (empty($_POST["lname"])) {
    $lnameErr = "last name is required";
  } else {
    // $lname = test_input($_POST["lname"]);
    if (!preg_match("/^[a-zA-Z-' ]*$/",$lname = test_input($_POST['lname']))) {
      $lnameErr = "Only letters and white space allowed";
  }
}
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }
  if (empty($_POST["Password"])) {
    $passwordErr = "password is required";
  } else {
    $pass = test_input($_POST["Password"]);
  }
  if (empty($_POST["username"])) {
    $usernameErr = "User name is required";
  } else {
    $user = test_input($_POST["username"]);
  }

  if (empty($_POST["course"])) {
    $courseErr = "course name is required";
  } else {
    $course = test_input($_POST["course"]);
  }

  if (empty($_POST["dddress"])) {
    $addressErr = "address is required";
  } else {
    $address = test_input($_POST["dddress"]);
  }
  
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

if(isset($_POST['submit'])){
 if($fname != "" && $lname != "" && $email != "" && $pass != "" && $user != "" && $user != "" && $course != "" && $address != "" ){
  $sql = "INSERT INTO `validate`( `first_name`, `last_name`, `email`, `passw`, `username`, `course`, `address`) 
  VALUES ('$fname','$lname','$email',md5('$pass'),'$user','$course','$address')";
    if(mysqli_query($conn, $sql)){

      ?> <script> 
        alert('Congratulation Data is Inserted Successfully'); </script> <?php
    }
    else{
      echo "error";
    }
}
 else{
    ?> <script> alert('Please fill the form'); </script> <?php
}

} 

mysqli_close($conn);



?>
