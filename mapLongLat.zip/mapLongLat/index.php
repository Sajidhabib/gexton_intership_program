<html>
  <head>
    <title>Enter Logitude and Latitude</title>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
#map {
    height: 400px;
    width: 50%;
    border = 2px solid red;
}
    </style>
  </head>
  <body>
  <center>
        <div class="">
            <h1 class="text-success">Enter Logitude and Latitude</h1>
            <br>
            <form method="POST" action="#" class="form-control ">
            <input type="text" class="form-control text-center" name="lat" placeholder="Enter Latitude for exapmle(47.1231231)" id="lat" >
           <br> <input type="text" class="form-control text-center" name="long" placeholder="Enter Longitude for exapmle(179.121212)" id="long" >
            <br><br>
            <input class="btn btn-danger" type="submit" name="submit" id="btn" value="Search" onclick="transfer()">
</form>
        </div>  </center>
        <br>
   <center>
  
    <div id="map"></div>
    </center>
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBzJ-ZlCQleWdz9IcPUDx_j9KutnYkUmY0&callback=transfer&v=weekly"
      defer
    ></script>

<?php
if(isset($_POST['submit'])){
  $lat = $_POST['lat'];
  $long = $_POST['long'];

}

?>
<script>

function transfer(){

    var map = new google.maps.Map(document.getElementById("map"), {
      zoom: 12,
      center: {lat: <?php echo $lat ?>, lng: <?php echo $long ?> }
    });
    var marker = new google.maps.Marker({
      position: hyderabad,
      map: map,
    });
  }
  window.transfer = transfer;

</script>
</body>
</html>